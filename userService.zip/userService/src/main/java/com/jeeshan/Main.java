package com.jeeshan;


import com.networknt.server.Server;

public class Main {
    public static void main(String[] args) {
        Server.start();
    }
}