package com.jeeshan.handlers;

import com.jeeshan.database.MongoDBUtil;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;
import com.networknt.handler.LightHttpHandler;
import io.undertow.server.HttpServerExchange;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserHandler implements LightHttpHandler {

    private MongoCollection<Document> userCollection;

    public UserHandler() {
        userCollection = MongoDBUtil.getDatabase().getCollection("users");
    }

    @Override
    public void handleRequest(HttpServerExchange exchange) throws Exception {
        String path = exchange.getRequestPath();
        String method = exchange.getRequestMethod().toString();

        switch (method) {
            case "GET":
                if (path.equals("/load")) {
                    loadUsers(exchange);
                } else if (path.startsWith("/users/")) {
                    String userId = path.substring(path.lastIndexOf("/") + 1);
                    getUserById(exchange, userId);
                }
                break;
            case "DELETE":
                if (path.equals("/users")) {
                    deleteAllUsers(exchange);
                } else if (path.startsWith("/users/")) {
                    String userId = path.substring(path.lastIndexOf("/") + 1);
                    deleteUserById(exchange, userId);
                }
                break;
            case "PUT":
                if (path.equals("/users")) {
                    addUser(exchange);
                }
                break;
            case "POST":
                if (path.startsWith("/users/")) {
                    String userId = path.substring(path.lastIndexOf("/") + 1);
                    updateUser(exchange, userId);
                }
                break;
            default:
                exchange.setStatusCode(405);
                exchange.getResponseSender().send("Method Not Allowed");
        }
    }

    private void loadUsers(HttpServerExchange exchange) throws IOException {
        // Fetch data from JSONPlaceholder and insert into MongoDB
        // Implement this logic
    }

    private void getUserById(HttpServerExchange exchange, String userId) {
        // Fetch user by ID from MongoDB
    }

    private void deleteAllUsers(HttpServerExchange exchange) {
        // Delete all users from MongoDB
    }

    private void deleteUserById(HttpServerExchange exchange, String userId) {
        // Delete user by ID from MongoDB
    }

    private void addUser(HttpServerExchange exchange) {
        // Add a new user to MongoDB
    }

    private void updateUser(HttpServerExchange exchange, String userId) {
        // Update an existing user in MongoDB
    }
}